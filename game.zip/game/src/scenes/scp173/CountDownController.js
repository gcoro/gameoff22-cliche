class CountdownController {
    constructor(scene) {
        this.scene = scene

        const timerLabel = this.scene.add.text(
            (this.scene.mapWidth  / 2 - 75) || (this.scene.game.config.width-150),
            30,
            `00:00`,
            {
                fixedWidth: 120,
                fixedHeight: 40,
                fontSize: "32px",
                fill: "black",
                backgroundColor: "white",
                align: "center",
            }
        )
        timerLabel.setPadding(0, 6)
        timerLabel.setScrollFactor(0)
        timerLabel.setDepth(7)
        timerLabel.alpha = 0.4

        this.label = timerLabel

        this.eventEmitter = EventDispatcher.getInstance()
        this.eventEmitter.once(SCENE_EVENTS.GAME_OVER, () => {
            this.label.text = "00:00"
            this.stop()
        })
    }

    start(duration) {
        this.duration = duration

        this.timerEvent = this.scene.time.addEvent({
            delay: duration,
            callback: () => {
                this.label.text = "00:00"
                this.scene.playerDeath("timer")
                this.stop()
            },
        })
    }

    stop() {
        if (this.timerEvent) {
            this.timerEvent.destroy()
            this.timerEvent = undefined
        }
    }

    update() {
        if (!this.timerEvent || this.duration <= 0) {
            return
        }

        const elapsed = this.timerEvent.getElapsed()
        const remaining = this.duration - elapsed
        const seconds = Math.floor(remaining / 1000)
        this.label.text = this.formatTime(seconds)
    }

    hide() {
        this.label.setActive(false).setVisible(false);
    }

    formatTime(seconds) {
        // Minutes
        const minutes = Math.floor(seconds / 60)
            .toString()
            .padStart(2, "0")
        // Seconds
        let partInSeconds = seconds % 60
        // Adds left zeros to seconds
        partInSeconds = partInSeconds.toString().padStart(2, "0")
        // Returns formated time
        return `${minutes}:${partInSeconds}`
    }
}
