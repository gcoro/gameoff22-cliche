# clichè, right?

## Assets used

### main scene

-   bg https://opengameart.org/content/sideview-sci-fi-patreon-collection
-   doors https://opengameart.org/content/lab-textures
-   alien https://craftpix.net/freebies/2d-game-alien-character-free-sprite/
-   audio door locked https://freesound.org/people/BenjaminNelan/sounds/321087/
-   audio door opening https://opengameart.org/content/door-open-sfx
-   audio main scene theme https://opengameart.org/content/green-gray 

### Scp 173

-   poops: https://www.gamedeveloperstudio.com/graphics/viewgraphic.php?page-name=poop-game-sprites&item=1g6v4g0e1k7m7b5411
- blood and bones: https://psychronic.com/abusive-prison-tileset/
- alien sprite: https://kenney.nl/assets
- alien guards: https://secrethideout.itch.io/team-wars-platformer-battle
- eye monster: https://kuuly.itch.io/covid-boss
-   cursor: https://opengameart.org/content/%E2%80%9Calien%E2%80%9D-crosshairs
- tile: quelle di davide che non abbiamo
